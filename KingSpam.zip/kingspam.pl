#!usr/bin/perl
#King Spam 1.0
#(C) Doddy Hackman 2015
# SMTP Servers
#smtp.gmail.com - 465
#smtp.mail.yahoo.com -587

use IO::Socket;
use Color::Output;
Color::Output::Init;
use Getopt::Long;

#use Win32::OLE;

my $nick_secundario    = "Cl4ptr4p";
my $timeout_secundario = "5";

GetOptions(
    "get_channels=s"         => \$get_channels,
    "get_users=s"            => \$get_users,
    "spam_channel=s"         => \$spam_channel,
    "spam_channel_forever=s" => \$spam_channel_forever,
    "spam_server=s"          => \$spam_server,
    "spam_servers_file=s"    => \$spam_servers_file,
    "spam_targets=s"         => \$spam_targets,
    "spam_file=s"            => \$spam_file,
    "channel=s"              => \$channel,
    "port=s"                 => \$port,
    "nick=s"                 => \$nick,
    "savefile=s"             => \$file,
    "timeout=s"              => \$timeout,
    "mailbomber"             => \$mailbomber
);

head();

if ($get_channels) {

    my $port_now = "";
    my $nick_now = "";
    my $file_now = "";

    if ( !$port ) {
        $port_now = "6667";
    }
    else {
        $port_now = $port;
    }

    if ( !$nick ) {
        $nick_now = $nick_secundario;
    }
    else {
        $nick_now = $nick;
    }

    if ( !$file ) {
        $file_now = "";
    }
    else {
        $file_now = $file;
    }

    listar_canales( $get_channels, $port_now, $nick_now, $file_now );

}
elsif ($get_users) {

    my $port_now = "";
    my $nick_now = "";
    my $file_now = "";

    if ( !$port ) {
        $port_now = "6667";
    }
    else {
        $port_now = $port;
    }

    if ( !$nick ) {
        $nick_now = $nick_secundario;
    }
    else {
        $nick_now = $nick;
    }

    printear_titulo("[+] Serching users ...\n\n");

    my @usuarios =
      buscar_usuarios( $get_users, $port_now, $nick_now, $channel );

    if ( int(@usuarios) eq "0" ) {
        printear("[-] Users not found\n");
    }
    else {
        printear("[+] Users Found : ");
        print int(@usuarios) . "\n\n";
        for my $usuario (@usuarios) {
            printear("[+] User : ");
            print $usuario. "\n";
            savefile( $file, $usuario );
        }
    }

}
elsif ($spam_channel) {

    my $port_now    = "";
    my $nick_now    = "";
    my $timeout_now = "";

    if ( !$port ) {
        $port_now = "6667";
    }
    else {
        $port_now = $port;
    }

    if ( !$nick ) {
        $nick_now = $nick_secundario;
    }
    else {
        $nick_now = $nick;
    }

    if ( !$timeout ) {
        $timeout_now = $timeout_secundario;
    }
    else {
        $timeout_now = $timeout;
    }

    spam_canal(
        $spam_channel, $port_now,  $nick_now,
        $channel,      $spam_file, $timeout_now
    );

}
elsif ($spam_channel_forever) {

    my $port_now    = "";
    my $nick_now    = "";
    my $timeout_now = "";

    if ( !$port ) {
        $port_now = "6667";
    }
    else {
        $port_now = $port;
    }

    if ( !$nick ) {
        $nick_now = $nick_secundario;
    }
    else {
        $nick_now = $nick;
    }

    if ( !$timeout ) {
        $timeout_now = $timeout_secundario;
    }
    else {
        $timeout_now = $timeout;
    }

    spam_canal_forever( $spam_channel_forever, $port_now, $nick_now,
        $channel, $spam_file, $timeout_now );

}
elsif ($spam_server) {

    my $port_now    = "";
    my $nick_now    = "";
    my $timeout_now = "";

    if ( !$port ) {
        $port_now = "6667";
    }
    else {
        $port_now = $port;
    }

    if ( !$nick ) {
        $nick_now = $nick_secundario;
    }
    else {
        $nick_now = $nick;
    }

    if ( !$timeout ) {
        $timeout_now = $timeout_secundario;
    }
    else {
        $timeout_now = $timeout;
    }

    my @encontrados = buscar_canales( $spam_server, $port_now, $nick_now );

    for my $encontrado (@encontrados) {
        if ( $encontrado =~ /(.*)-soy_un_limite-(.*)/ ) {
            my $canal    = $1;
            my $cantidad = $2;

            spam_canal( $spam_server, $port_now, $nick_now, $canal, $spam_file,
                $timeout_now );

        }
    }

}
elsif ($spam_servers_file) {

    my $port_now    = "";
    my $nick_now    = "";
    my $timeout_now = "";

    if ( !$port ) {
        $port_now = "6667";
    }
    else {
        $port_now = $port;
    }

    if ( !$nick ) {
        $nick_now = $nick_secundario;
    }
    else {
        $nick_now = $nick;
    }

    if ( !$timeout ) {
        $timeout_now = $timeout_secundario;
    }
    else {
        $timeout_now = $timeout;
    }

    unless ( -f $spam_servers_file ) {
        printear("[-] File not found\n\n");
        copyright();
    }
    else {

        my @lista = loadfile($spam_servers_file);

        printear("[+] Servers Found : ");
        print int(@lista) . "\n";

        printear_titulo(
            "\n-------------------------------------------------------------\n"
        );

        for my $spam_server (@lista) {
            chomp $spam_server;
            my @encontrados =
              buscar_canales( $spam_server, $port_now, $nick_now );

            for my $encontrado (@encontrados) {
                chomp $encontrado;
                if ( $encontrado =~ /(.*)-soy_un_limite-(.*)/ ) {
                    my $canal    = $1;
                    my $cantidad = $2;

                    spam_canal( $spam_server, $port_now, $nick_now, $canal,
                        $spam_file, $timeout_now );
                    printear_titulo(
"\n-------------------------------------------------------------\n"
                    );
                }
            }
        }
    }

}
elsif ($spam_targets) {

    my $port_now    = "";
    my $nick_now    = "";
    my $timeout_now = "";

    if ( !$port ) {
        $port_now = "6667";
    }
    else {
        $port_now = $port;
    }

    if ( !$nick ) {
        $nick_now = $nick_secundario;
    }
    else {
        $nick_now = $nick;
    }

    if ( !$timeout ) {
        $timeout_now = $timeout_secundario;
    }
    else {
        $timeout_now = $timeout;
    }

    if ( -f $spam_targets ) {

        my @datos = loadfile($spam_targets);

        printear("[+] Servers Found : ");
        print int(@datos) . "\n";

        printear_titulo(
            "\n-------------------------------------------------------------\n"
        );

        for my $dato (@datos) {
            chomp $dato;
            if ( $dato =~ /(.*) --- (.*)/ ) {
                my $server = $1;
                my $canal  = $2;

                spam_canal( $server, $port_now, $nick_now, $canal, $spam_file,
                    $timeout_now );
                printear_titulo(
"\n-------------------------------------------------------------\n"
                );

            }
        }

    }
    else {
        printear("\n[-] File not Found\n\n");
        copyright();
    }

}
elsif ($mailbomber) {

    printear_titulo("[+] Spam Mails : OK\n\n\n");

    printear("[+] Host : ");
    chomp( my $host = <stdin> );

    printear("\n[+] Port : ");
    chomp( my $puerto = <stdin> );

    printear("\n[+] Username : ");
    chomp( my $username = <stdin> );

    printear("\n[+] Password : ");
    chomp( my $password = <stdin> );

    printear("\n[+] Count Message : ");
    chomp( my $count = <stdin> );

    printear("\n[+] To : ");
    chomp( my $to = <stdin> );

    printear("\n[+] Subject : ");
    chomp( my $asunto = <stdin> );

    printear("\n[+] Body : ");
    chomp( my $body = <stdin> );

    printear("\n[+] File to Send : ");
    chomp( my $file = <stdin> );

    printear_titulo("\n[+] Starting ...\n\n");

    for my $num ( 1 .. $count ) {
        printear("[+] Sending Message : ");
        print "$num\n";
        sendmail(
            $host,     $puerto, $username, $password, $username, $username,
            $username, $to,     $asunto,   $body,     $file
        );
    }

    printear_titulo("\n[+] Finished\n");

}
else {
    sintax();
}

copyright();

# Functions

sub spam_canal {

    my $hostname = $_[0];
    my $port     = $_[1];
    my $nombre   = $_[2];
    my $canal    = $_[3];
    my $archivo  = $_[4];

    printear("[+] Connecting to ");
    print $hostname. "\n\n";

    my @nicks    = buscar_usuarios( $_[0], $_[1], $_[2], $_[3] );
    my $contador = 0;
    my $termine  = 0;
    my $timeout  = $_[5];

    my @spamnow = loadfile($archivo);

    if (
        my $socket = new IO::Socket::INET(
            PeerAddr => $hostname,
            PeerPort => $port,
            Proto    => "tcp"
        )
      )
    {

        print $socket "NICK $nombre\r\n";
        print $socket "USER $nombre 1 1 1 1\r\n";
        print $socket "JOIN $canal\r\n";

        printear_titulo("[+] Users Found : ");
        print int(@nicks) . "\n\n";

        while ( my $log = <$socket> ) {
            chomp $log;

            if ( $log =~ /^PING(.*)$/i ) {
                print $socket "PONG $1\r\n";
            }

            if ( $contador eq "0" ) {
                printear("[+] Spam in channel : ");
                print $canal. "\n";
                sleep($timeout);
                print $socket "PRIVMSG $canal "
                  . $spamnow[ rand(@spamnow) ] . "\r\n";
                $contador++;
            }

            foreach $names (@nicks) {
                chomp $names;
                sleep($timeout);
                unless ( $nombre eq $names ) {
                    $names =~ s/\@//;
                    $names =~ s/\+//;
                    print $socket "PRIVMSG $names $spamnow[rand(@spamnow)]\r\n";
                    printear("[+] Spam to user $names : ");
                    print "OK\n";
                }
                $termine++;
            }

            if ( $termine eq int(@nicks) ) {
                $socket->close();
                last;
            }

        }
    }
    else {
        printear("[-] Error\n");
        $socket->close();
    }

}

sub spam_canal_forever {

    my $hostname = $_[0];
    my $port     = $_[1];
    my $nombre   = $_[2];
    my $canal    = $_[3];
    my $archivo  = $_[4];

    printear("[+] Connecting to ");
    print $hostname. "\n\n";

    my @nicks    = buscar_usuarios( $_[0], $_[1], $_[2], $_[3] );
    my $contador = 0;
    my $termine  = 0;
    my $timeout  = $_[5];

    my @spamnow = loadfile($archivo);

    if (
        my $socket = new IO::Socket::INET(
            PeerAddr => $hostname,
            PeerPort => $port,
            Proto    => "tcp"
        )
      )
    {

        print $socket "NICK $nombre\r\n";
        print $socket "USER $nombre 1 1 1 1\r\n";
        print $socket "JOIN $canal\r\n";

        printear_titulo("[+] Users Found : ");
        print int(@nicks) . "\n\n";

        while ( my $log = <$socket> ) {
            chomp $log;

            while (1) {
                if ( $log =~ /^PING(.*)$/i ) {
                    print $socket "PONG $1\r\n";
                }

                if ( $contador eq "0" ) {
                    printear("[+] Spam in channel : ");
                    print $canal. "\n";
                    sleep($timeout);
                    print $socket "PRIVMSG $canal "
                      . $spamnow[ rand(@spamnow) ] . "\r\n";
                    $contador++;
                }

                foreach $names (@nicks) {
                    chomp $names;
                    sleep($timeout);
                    unless ( $nombre eq $names ) {
                        $names =~ s/\@//;
                        $names =~ s/\+//;
                        print $socket
                          "PRIVMSG $names $spamnow[rand(@spamnow)]\r\n";
                        printear("[+] Spam to user $names : ");
                        print "OK\n";
                    }
                    $termine++;
                }
                $contador = 0;
                print "\n";
            }

            if ( $termine eq int(@nicks) ) {
                $socket->close();
                last;
            }

        }
    }
    else {
        printear("[-] Error\n");
        $socket->close();
    }

}

sub buscar_usuarios {

    my $hostname = $_[0];
    my $port     = $_[1];
    my $nombre   = $_[2];
    my $canal    = $_[3];

    if (
        my $socket = new IO::Socket::INET(
            PeerAddr => $hostname,
            PeerPort => $port,
            Proto    => "tcp"
        )
      )
    {

        print $socket "NICK $nombre\r\n";
        print $socket "USER $nombre 1 1 1 1\r\n";
        print $socket "JOIN $canal\r\n";

        while ( my $log = <$socket> ) {

            chomp $log;

            if ( $log =~ /^PING(.*)$/i ) {
                print $socket "PONG $1\r\n";
            }

            if ( $log =~ m/:(.*) 353 (.*) = (.*) :(.*)/ig ) {
                my $pro = $4;
                chop $pro;
                $pro =~ s/$nombre//;
                my @nicks = split " ", $pro;
                $socket->close();
                return @nicks;
            }

        }
    }
}

sub buscar_canales {

    my @resultado;

    my $hostname = $_[0];
    my $port     = $_[1];
    my $nombre   = $_[2];

    if (
        my $socket = new IO::Socket::INET(
            PeerAddr => $hostname,
            PeerPort => $port,
            Proto    => "tcp"
        )
      )
    {

        print $socket "NICK $nombre\r\n";
        print $socket "USER $nombre 1 1 1 1\r\n";
        print $socket "LIST\r\n";

        while ( my $log = <$socket> ) {

            if ( $log =~ /322 (.*?) (.*?) (.*?) :/ ) {
                my $canal    = $2;
                my $cantidad = $3;
                push( @resultado, $canal . "-soy_un_limite-" . $cantidad );
            }

            if ( $log =~ /:End of \/LIST/ ) {
                last;
            }

        }

        $socket->close;

        return @resultado;

    }

}

sub listar_canales {

    my $host = $_[0];
    my $port = $_[1];
    my $nick = $_[2];
    my $file = $_[3];

    printear_titulo("[+] Serching channels ...\n\n");
    my @encontrados = buscar_canales( $host, $port, $nick );
    if ( int(@encontrados) eq "0" or int(@encontrados) eq "1" ) {
        printear_titulo("[-] Channels not found\n");
    }
    else {
        printearf_titulo( "Channels", "Users" );
        print "\n";
        for my $encontrado (@encontrados) {
            if ( $encontrado =~ /(.*)-soy_un_limite-(.*)/ ) {
                my $canal    = $1;
                my $cantidad = $2;
                printearf( $canal, $cantidad );

                if ( $file ne "" ) {
                    savefile( $file, $canal );
                }

            }
        }
    }

}

sub sendmail {

## Function Based on : http://code.activestate.com/lists/pdk/5351/
## Credits : Thanks to Phillip Richcreek and Eric Promislow

    my (
        $host, $port, $username, $password, $from, $cc,
        $bcc,  $to,   $asunto,   $mensaje,  $file
    ) = @_;

    $correo = Win32::OLE->new('CDO.Message');

    $correo->Configuration->Fields->SetProperty( "Item",
        'http://schemas.microsoft.com/cdo/configuration/sendusername',
        $username );
    $correo->Configuration->Fields->SetProperty( "Item",
        'http://schemas.microsoft.com/cdo/configuration/sendpassword',
        $password );
    $correo->Configuration->Fields->SetProperty( "Item",
        'http://schemas.microsoft.com/cdo/configuration/smtpserver', $host );
    $correo->Configuration->Fields->SetProperty( "Item",
        'http://schemas.microsoft.com/cdo/configuration/smtpserverport',
        $port );
    $correo->Configuration->Fields->SetProperty( "Item",
        'http://schemas.microsoft.com/cdo/configuration/smtpusessl', 1 );
    $correo->Configuration->Fields->SetProperty( "Item",
        'http://schemas.microsoft.com/cdo/configuration/sendusing', 2 );
    $correo->Configuration->Fields->SetProperty( "Item",
        'http://schemas.microsoft.com/cdo/configuration/smtpauthenticate', 1 );
    $correo->Configuration->Fields->Update();

    if ( -f $file ) {
        $correo->AddAttachment($file);
    }

    $correo->{From}     = $from;
    $correo->{CC}       = $cc;
    $correo->{BCC}      = $bcc;
    $correo->{To}       = $to;
    $correo->{Subject}  = $asunto;
    $correo->{TextBody} = $mensaje;
    $correo->Send();

}

# More Functions

sub printearf_titulo {
    cprintf( "\x0310" . "%-32s  %s" . "\x030\n", $_[0], $_[1] );
}

sub printearf {
    cprintf( "\x036" . "%-32s  %s" . "\x030\n", $_[0], $_[1] );
}

sub printear {
    cprint( "\x036" . $_[0] . "\x030" );
    return "";
}

sub printear_logo {
    cprint( "\x037" . $_[0] . "\x030" );
    return ""

}

sub printear_titulo {
    cprint( "\x0310" . $_[0] . "\x030" );
    return "";
}

sub savefile {
    open( SAVE, ">>" . $_[0] );
    print SAVE $_[1] . "\n";
    close SAVE;
}

sub loadfile {
    if ( -f $_[0] ) {
        my @words;
        my @r;
        open( FILE, $_[0] );
        @words = <FILE>;
        close FILE;
        for (@words) {
            push( @r, $_ );
        }
        return (@r);
    }
    else {
        printear("\n[-] File not found\n\n");
        copyright();
    }
}

sub sintax {
    printear("[+] Sintax : ");
    print "perl $0 <option> <value>\n";
    printear("\n[+] Options : \n\n");
    print
"-get_channels <host> -port <port> -nick <nick> -savefile <file> : Get & Save Channels of a server\n";
    print
"-get_users <host> -port <port> -channel <channel> -nick <nick> -savefile <file> : Get & Save Channels of a server\n";
    print
"-spam_channel <host> -port <port> -channel <channel> -nick <nick> -spam_file <spam> -timeout <timeout> : Spam in a Channel\n";
    print
"-spam_channel_forever <host> -port <port> -channel <channel> -nick <nick> -spam_file <spam> -timeout <timeout> : Spam in a Channel Forever\n";
    print
"-spam_server <host> -port <port> -nick <nick> -spam_file <spam> -timeout <timeout> : Spam in a server\n";
    print
"-spam_servers_list <file> -port <port> -nick <nick> -spam_file <spam> -timeout <timeout> : Spam in multiple servers\n";
    print
"-spam_targets <file> -port <port> -nick <nick> -spam_file <spam> -timeout <timeout> : Spam in servers & channels saved\n";
    print "-mailbomber : Open MailBomber\n";
    printear("\n[+] Example : \n\n");
    print "perl kingspam.pl -get_channels localhost\n";
    print "perl kingspam.pl -get_users localhost -channel #locos\n";
    print
"perl kingspam.pl -spam_channel localhost -channel #locos -spam_file c:/spam.txt\n";
    print
"perl kingspam.pl -spam_channel_forever localhost -channel #locos -spam_file c:/spam.txt\n";
    print "perl kingspam.pl -spam_server localhost -spam_file c:/spam.txt\n";
    print
"perl kingspam.pl -spam_servers_file c:/servers.txt -nick ClapTrap -spam_file c:/spam.txt\n";
    print
      "perl kingspam.pl -spam_targets c:/servers.txt -spam_file c:/spam.txt\n";
    print "perl kingspam.pl -mailbomber\n";
}

sub head {
    printear_logo("\n-- == KingSpam 1.0 == --\n\n\n");
}

sub copyright {
    printear_logo("\n\n-- == (C) Doddy Hackman 2015 == --\n\n");
    exit(1);
}

# The End ?
